#!/bin/bash
source __VENVBIN__/activate

exec __EXE__
