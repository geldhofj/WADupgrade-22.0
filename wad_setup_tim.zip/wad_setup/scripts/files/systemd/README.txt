systemctl3.py
=============
url: https://github.com/gdraheim/docker-systemctl-replacement
author: Guido Draheim
license: EUPL-LICENSE

changes to original source:
    * added "mask" command; 
    * also ignore lines starting with "@", and '!!'
